import 'package:flutter/material.dart';
import 'package:wallpaper_ui/ui/colortone_page.dart';

void main() {
  runApp(MainApp());
}

class MainApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: WallpaperTone(),
    );
  }
}
